/* Show login form on button click */
 
jQuery('.loginBtn').click(function(){
  jQuery('.login').show();
  jQuery('.signUp').hide();
  /* border bottom on button click */
  jQuery('.loginBtn').css({'border-bottom' : '2px solid #ff4141'});
  /* remove border after click */
  jQuery('.signUpBtn').css({'border-style' : 'none'});
});
 
 
/* Show sign Up form on button click */
 
jQuery('.signUpBtn').click(function(){
  jQuery('.login').hide();
  jQuery('.signUp').show();
  /* border bottom on button click */
  jQuery('.signUpBtn').css({'border-bottom' : '2px solid #ff4141'});
   /* remove border after click */
   jQuery('.loginBtn').css({'border-style' : 'none'});
});

// Error Validation

// function isEmpty(){
//   var i = document.querySelector(".rgform-error");
//   var str = document.forms['myForm'].userName.value;
//   if( !str.replace(/\s+/, '').length && i.style.display === "none") {
//       // alert( "The Name field is empty!" );
//         i.style.display = "block";
//       // return false;
//   }
// }